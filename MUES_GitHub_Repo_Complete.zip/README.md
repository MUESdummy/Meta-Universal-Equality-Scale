
# M.U.E.S. — Meta Universal Equality Scale
By Vale & AlWaleed K

---

## Overview

MUES is not a quiz. It's a cognitive mirror. It measures your:
- Intent vs. Impact
- Self-awareness & contradiction tolerance
- Truth alignment
- Systemic coherence
- Entropic disruption

This version includes:
- Prompt-by-prompt interaction
- Consistency pattern detection
- Archetype + score output
- Logo, branding, and sync boot sequence

Live demo: https://mues.tools/start  
Scan QR: [MUES_QR_Launch.png]

---

## Getting Started

```bash
npm install
npm run dev
```

Then go to: `http://localhost:3000`

## Deployment

Use Vercel for automatic frontend deployment.

---

MUES doesn’t flatter. It reveals.
